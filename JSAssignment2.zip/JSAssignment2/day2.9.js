function greater(){
    s=0;
    for(var i=0;i<arguments.length;i++){
       if(s>arguments[i]||s==arguments[i]){
return s;
       } 
       else{
        s=arguments[i];
       }
    }
    return s;
}
console.log(greater(1,2,3,4,5,10));

console.log(greater(10,200,35,56,560,70,1));