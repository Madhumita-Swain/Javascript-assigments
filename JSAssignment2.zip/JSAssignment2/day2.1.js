
function factorial(num){
if(num==0){
   console.log('The factoial of number is 1');
}
else if(num<0){
    console.log('not possible');

}
else{
    for(var i=1;i<=num;i++){
        fact=fact*i;
        
    }
    
}
return fact;
}
var num=prompt("enter the no");
var fact=1;
document.write((factorial(num)));