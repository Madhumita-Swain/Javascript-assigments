
function sum(){
    var s=0;
    for(var i=0;i<arguments.length;i++){
        s+=arguments[i];
    }
    return s;
}
console.log(sum(2,3));
console.log(sum(3,4,5,6,7));
console.log(sum());