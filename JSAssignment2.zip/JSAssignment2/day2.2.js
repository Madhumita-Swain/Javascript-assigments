
const sum=(a,b)=>a+b;
console.log('sum is:'+sum(5,7));