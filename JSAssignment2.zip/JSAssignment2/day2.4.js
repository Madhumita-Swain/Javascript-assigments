/*	Write a JS arrow function named Login() which takes a username and password. In case any of the arguments or both are not passed, the default values must be CT and CT respectively*/
function validateForm() {
    let x = document.forms["myForm"]["fname"].value;
    let y = document.forms["myForm"]["fpass"].value;

    if(x == '' || y == '')
        x = 'CT';
        y = 'CT';

    document.forms['myForm']['fname'].value = x;
    document.forms['myForm']['fpass'].value = y;

    
}