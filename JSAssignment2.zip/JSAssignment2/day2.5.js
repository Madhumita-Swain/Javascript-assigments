/*5.	Create a JS object which stores the following details about a vehicle:
vehicleid                a number
brand                      a string
model                     a string
variant                    a string
specifications             an object containing the following members:
                                    firstGear          a function which logs some message
                                    secondGear     a function which logs some message
                                    maxSpeed       a number
                                    changeGear    a function which calls “firstGear” and 
    “secondGear” functions 
Print the vehicleid, brand, model, variant on the browser console. Invoke the changeGear function & display the speed on the browser console.*/
const vehicle = {
    brand: 'Mercedes-Benz',
    model: 'A-class',
    vehicleId: 101,
    variant: 'A-Class A200 D Sport Edition',

    specifications:
    {
        //firstGear: function () { console.log('first gear of vehicle'); },
        //secondGear: function () { console.log('second gear of vehicle'); },
        
        firstGear:'first gear of vehicle',
        secondGear: 'second gear of vehicle',
        maxSpeed: 150,
        changeGear() {
            return this.firstGear + ' ' + this.secondGear;

        }

    }

};



console.log('vehicle id: ' + vehicle['vehicleId']);
console.log('Brand:' + vehicle['brand']);
console.log('model:' + vehicle['model']);
console.log('variant:' + vehicle['variant']);
console.log('Speed:' + vehicle.specifications.maxSpeed);
console.log('Change gear:' + vehicle.specifications.changeGear());