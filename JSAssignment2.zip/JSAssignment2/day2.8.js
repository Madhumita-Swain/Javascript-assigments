
const vehicle = {
    brand: 'Mercedes-Benz',
    model: 'A-class',
    vehicleId: 101,
    variant: 'A-Class A200 D Sport Edition',

    specifications:
    {
        //firstGear: function () { console.log('first gear of vehicle') },
        //secondGear: function () { console.log('second gear of vehicle') },

        
        firstGear: 'first gear of vehicle',
        secondGear: 'second gear of vehicle',
        maxSpeed: 150,
        changeGear() {
            return this.firstGear + ' ' + this.secondGear;

        }

    }

}

const showVehicleDetails  = vehicle => {
    console.log(showVehicleDetails.vehicle.vehicleId);
    console.log(showVehicleDetails.vehicle.brand);
    console.log(showVehicleDetails.vehicle.model);
    console.log(showVehicleDetails.vehicle.variant);
    console.log(showVehicleDetails.vehicle.specifications.maxSpeed);
};



