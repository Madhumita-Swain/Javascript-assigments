console.log(print(1,2,3));
function print(){
    for(let i=0;i<arguments.length;i++){
        document.write(i+"<br>");
    }
    document.write("number of arguments are:");
    let count=0;
    for(let i=0;i<arguments.length;i++){
        count++;
    }
    document.write(count);
}